LICENSE
-------

These ArchiMate 3.1 stencils including ArchiMate 3.1 Notation Overview have been created by Goodea and are available under CC BY-NC-ND license (http://creativecommons.org/licenses).
 
You can freely use the stencils for creating visualizations. 
Without Goodea written consent you are not allowed to resell them, embed tou your products, modify and publish them.

If unsure, check the license conditions with Goodea at stencils@goodea.eu.

Please provide a feedback and report bugs to stencils@goodea.eu.

Thank you and visit us at www.goodea.eu.

RELEASE NOTES
-------------
Version 1.3
ArchiMate 3.1 support

Version 1.2
Added support for Visio versions 2003 to 2010
Connectors now support curved, angled or straight options
Composition end glue to shape behaviour fixed
Composite elements moved to separate stencil file

Version 1.1
Fixed composition end rotation
Representation - top line added according to the specification
Plateau changed to 3D according to specification
Capability - text field focus fixed
